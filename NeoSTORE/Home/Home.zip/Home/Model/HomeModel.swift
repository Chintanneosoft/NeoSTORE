//
//  HomeModel.swift
//  NeoSTORE
//
//  Created by Neosoft1 on 21/08/23.
//

import UIKit

enum Positions{
    case topLeft
    case topRight
    case bottomLeft
    case bottomRight
}

class HomeModel: NSObject {

}
